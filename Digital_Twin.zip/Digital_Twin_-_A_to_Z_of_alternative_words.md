# The A to Z of alternative words

*© Plain English Campaign 2024*

## Calling all writers

This guide gives hundreds of plain English alternatives to the pompous words and phrases that litter official writing. On its own the guide won't teach you how to write in plain English. There's more to it than just replacing 'hard' words with 'easy' words, and many of these alternatives won't work in every situation. But it will help if you want to get rid of words like 'notwithstanding', 'expeditiously' and phrases like 'in the majority of instances' and 'at this moment in time'. And using everyday words is an important first step towards clearer writing.

### Copyright

Plain English Campaign owns the copyright on this guide. You must not copy it without getting our permission first. You can download your own copy from our website (www.plainenglish.co.uk).

### Using the A to Z

If you find yourself about to write, type or dictate a word you wouldn't use in every day conversation, look it up in the A to Z. You should find a simpler alternative. Often there will be a choice of several words. You need to pick the one that best fits what you are trying to say.

---

## A

| Word/phrase | Alternative |
| --- | --- |
| (an) absence of | no, none |
| abundance | enough, plenty, a lot (or say how many) |
| accede to | allow, agree to |
| accelerate | speed up |
| accentuate | stress |
| accommodation | where you live, home |
| accompanying | with |
| accomplish | do, finish |
| according to our records | our records show |
| accordingly | in line with this, so |
| acknowledge | thank you for |
| acquaint yourself with | find out about, read |
| acquiesce | agree |
| acquire | buy, get |
| additional | extra, more |
| adjacent | next to |
| adjustment | change, alteration |
| admissible | allowed, acceptable |
| advantageous | useful, helpful |
| advise | tell, say (unless you are giving advice) |
| affix | add, write, fasten, stick on, fix to |
| afford an opportunity | let, allow |
| afforded | given |
| aforesaid | this, earlier in this document |
| aggregate | total |
| aligned | lined up, in line |
| alleviate | ease, reduce |
| allocate | divide, share, add, give |
| along the lines of | like, as in |
| alternative | choice, other |
| alternatively | or, on the other hand |
| ameliorate | improve, help |
| amendment | change |
| anticipate | expect |
| apparent | clear, plain, obvious, seeming |
| applicant (the) | you |
| application | use |
| appreciable | large, great |
| apprise | inform, tell |
| appropriate | proper, right, suitable |
| appropriate to | suitable for |
| approximately | about, roughly |
| as a consequence of | because |
| as of the date of | from |
| as regards | about, on the subject of |
| ascertain | find out |
| assemble | build, gather, put together |
| assistance | help |
| at an early date | soon (or say when) |
| at its discretion | can, may (or edit out) |
| at the moment | now (or edit out) |
| at the present time | now (or edit out) |
| attempt | try |
| attend | come to, go to, be at |
| attributable to | due to, because of |
| authorise | allow, let |
| authority | right, power, may (as in 'have the authority to') |
| axiomatic | obvious, goes without saying |

## B

| Word/phrase | Alternative |
| --- | --- |
| belated | late |
| beneficial | helpful, useful |
| bestow | give, award |
| breach | break |
| by means of | by |

## C

| Word/phrase | Alternative |
| --- | --- |
| calculate | work out, decide |
| cease | finish, stop, end |
| circumvent | get round, avoid, skirt, circle |
| clarification | explanation, help |
| combine | mix |
| combined | together |
| commence | start, begin |
| communicate | talk, write, telephone (be specific) |
| competent | able, can |
| compile | make, collect |
| complete | fill in, finish |
| completion | end |
| comply with | keep to, meet |
| component | part |
| comprise | make up, include |
| (it is) compulsory | (you) must |
| conceal | hide |
| concerning | about, on |
| conclusion | end |
| concur | agree |
| condition | rule |
| consequently | so |
| considerable | great, important |
| constitute | make up, form |
| construe | interpret |
| consult | talk to, meet, ask |
| consumption | amount used |
| contemplate | think about |
| contrary to | against, despite |
| correct | put right |
| correspond | write |
| costs the sum of | costs |
| counter | against |
| courteous | polite |
| cumulative | added up, added together |
| currently | now (or edit out) |
| customary | usual, normal |

## D

| Word/phrase | Alternative |
| --- | --- |
| deduct | take off, take away |
| deem to be | treat as |
| defer | put off, delay |
| deficiency | lack of |
| delete | cross out |
| demonstrate | show, prove |
| denote | show |
| depict | show |
| designate | point out, show, name |
| desire | wish, want |
| despatch or dispatch | send, post |
| despite the fact that | though, although |
| determine | decide, work out, set, end |
| detrimental | harmful, damaging |
| difficulties | problems |
| diminish | lessen, reduce |
| disburse | pay, pay out |
| discharge | carry out |
| disclose | tell, show |
| disconnect | cut off, unplug |
| discontinue | stop, end |
| discrete | separate |
| discuss | talk about |
| disseminate | spread |
| documentation | papers, documents |
| domiciled in | living in |
| dominant | main |
| due to the fact of | because, as |
| duration | time, life |
| during which time | while |
| dwelling | home |

## E

| Word/phrase | Alternative |
| --- | --- |
| economical | cheap, good value |
| eligible | allowed, qualified |
| elucidate | explain, make clear |
| emphasise | stress |
| empower | allow, let |
| enable | allow |
| enclosed | inside, with |
| (please find) enclosed | I enclose |
| encounter | meet |
| endeavour | try |
| enquire | ask |
| enquiry | question |
| ensure | make sure |
| entitlement | right |
| envisage | expect, imagine |
| equivalent | equal, the same |
| erroneous | wrong |
| establish | show, find out, set up |
| evaluate | test, check |
| evince | show, prove |
| ex officio | because of his or her position |
| exceptionally | only when, in this case |
| excessive | too many, too much |
| exclude | leave out |
| excluding | apart from, except |
| exclusively | only |
| exempt from | free from |
| expedite | hurry, speed up |
| expeditiously | as soon as possible, quickly |
| expenditure | spending |
| expire | run out |
| extant | current, in force |
| extremity | limit |

## F

| Word/phrase | Alternative |
| --- | --- |
| fabricate | make, make up |
| facilitate | help, make possible |
| factor | reason |
| failure to | if you do not |
| finalise | end, finish |
| following | after |
| for the duration of | during, while |
| for the purpose of | to, for |
| for the reason that | because |
| formulate | plan, devise |
| forthwith | now, at once |
| forward | send |
| frequently | often |
| furnish | give |
| further to | after, following |
| furthermore | then, also, and |

## G

| Word/phrase | Alternative |
| --- | --- |
| generate | produce, give, make |
| give consideration to | consider, think about |
| grant | give |

## H

| Word/phrase | Alternative |
| --- | --- |
| henceforth | from now on, from today |
| hereby | now, by this (or edit out) |
| herein | here (or edit out) |
| hereinafter | after this (or edit out) |
| hereof | of this |
| hereto | to this |
| heretofore | until now, previously |
| hereunder | below |
| herewith | with this (or edit out) |
| hitherto | until now |
| hold in abeyance | wait, postpone |
| hope and trust | hope, trust (but not both) |

## I

| Word/phrase | Alternative |
| --- | --- |
| if and when | if, when (but not both) |
| illustrate | show, explain |
| immediately | at once, now |
| implement | carry out, do |
| imply | suggest, hint at |
| in a number of cases | some (or say how many) |
| in accordance with | as under, in line with, because of |
| in addition (to) | and, as well as, also |
| in advance | before |
| in case of | if |
| in conjunction with | and, with |
| in connection with | for, about |
| in consequence | because, as a result |
| in excess of | more than |
| in lieu of | instead of |
| in order that | so that |
| in receipt of | get, have, receive |
| in relation to | about |
| in respect of | about, for |
| in the absence of | without |
| in the course of | while, during |
| in the event of/that | if |
| in the majority of instances | most, mostly |
| in the near future | soon |
| in the neighbourhood of | about, around |
| in view of the fact that | as, because |
| inappropriate | wrong, unsuitable |
| inception | start, beginning |
| incorporating | which includes |
| incurred | have to pay, owe |
| indicate | show, suggest |
| inform | tell |
| initially | at first |
| initiate | begin, start |
| insert | put in |
| instances | cases |
| intend to | will |
| intimate | say, hint |
| irrespective of | despite, even if |
| is in accordance with | agrees with, follows |
| is of the opinion | thinks |
| issue | give, send |
| it is known that | I/we know that |

## J

| Word/phrase | Alternative |
| --- | --- |
| jeopardise | risk, threaten |

## L

| Word/phrase | Alternative |
| --- | --- |
| (a) large number of | many, most (or say how many) |
| (to) liaise with | to meet with, to discuss with, to work with (whichever is more descriptive) |
| locality | place, area |
| locate | find, put |

## M

| Word/phrase | Alternative |
| --- | --- |
| magnitude | size |
| (it is) mandatory | (you) must |
| manner | way |
| manufacture | make |
| marginal | small, slight |
| material | relevant |
| materialise | happen, occur |
| may in the future | may, might, could |
| merchandise | goods |
| mislay | lose |
| modification | change |
| moreover | and, also, as well |

## N

| Word/phrase | Alternative |
| --- | --- |
| negligible | very small |
| nevertheless | but, however, even so |
| notify | tell, let us/you know |
| notwithstanding | even if, despite, still, yet |
| numerous | many (or say how many) |

## O

| Word/phrase | Alternative |
| --- | --- |
| objective | aim, goal |
| (it is) obligatory | (you) must |
| obtain | get, receive |
| occasioned by | caused by, because of |
| on behalf of | for |
| on numerous occasions | often |
| on receipt of | when we/you get |
| on request | if you ask |
| on the grounds that | because |
| on the occasion that | when, if |
| operate | work, run |
| optimum | best, ideal |
| option | choice |
| ordinarily | normally, usually |
| otherwise | or |
| outstanding | unpaid |
| owing to | because of |

## P

| Word/phrase | Alternative |
| --- | --- |
| (a) percentage of | some (or say what percentage) |
| partially | partly |
| participate | join in, take part |
| particulars | details, facts |
| per annum | a year |
| perform | do |
| permissible | allowed |
| permit | let, allow |
| personnel | people, staff |
| persons | people, anyone |
| peruse | read, read carefully, look at |
| place | put |
| possess | have, own |
| possessions | belongings |
| practically | almost, nearly |
| predominant | main |
| prescribe | set, fix |
| preserve | keep, protect |
| previous | earlier, before, last |
| principal | main |
| prior to | before |
| proceed | go ahead |
| procure | get, obtain, arrange |
| profusion of | plenty, too many (or say how many) |
| (to) progress something | (replace with a more precise phrase saying what you are doing) |
| prohibit | ban, stop |
| projected | estimated |
| prolonged | long |
| promptly | quickly, at once |
| promulgate | advertise, announce |
| proportion | part |
| provide | give |
| provided that | if, as long as |
| provisions | rules, terms |
| proximity | closeness, nearness |
| purchase | buy |
| pursuant to | under, because of, in line with |

## Q

| Word/phrase | Alternative |
| --- | --- |
| qualify for | can get, be able to get |

## R

| Word/phrase | Alternative |
| --- | --- |
| reconsider | think again about, look again at |
| reduce | cut |
| reduction | cut |
| referred to as | called |
| refer to | talk about, mention |
| (have) regard to | take into account |
| regarding | about, on |
| regulation | rule |
| reimburse | repay, pay back |
| reiterate | repeat, restate |
| relating to | about |
| remain | stay |
| remainder | the rest, what is left |
| remittance | payment |
| remuneration | pay, wages, salary |
| render | make, give, send |
| represent | show, stand for, be |
| request | ask, question |
| require | need, want, force |
| requirements | needs, rules |
| reside | live |
| residence | home, where you live |
| restriction | limit |
| retain | keep |
| review | look at (again) |
| revised | new, changed |

## S

| Word/phrase | Alternative |
| --- | --- |
| said/such/same | the, this, that |
| scrutinise | read (look at) carefully |
| select | choose |
| settle | pay |
| similarly | also, in the same way |
| solely | only |
| specified | given, written, set |
| state | say, tell us, write down |
| statutory | legal, by law |
| subject to | depending on, under, keeping to |
| submit | send, give |
| subsequent to/upon | after |
| subsequently | later |
| substantial | large, great, a lot of |
| substantially | more or less |
| sufficient | enough |
| supplement | go with, add to |
| supplementary | extra, more |
| supply | give, sell, delivery |

## T

| Word/phrase | Alternative |
| --- | --- |
| (the) tenant | you |
| terminate | stop, end |
| that being the case | if so |
| the question as to whether | whether |
| thereafter | then, afterwards |
| thereby | by that, because of that |
| therein | in that, there |
| thereof | of that |
| thereto | to that |
| thus | so, therefore |
| to date | so far, up to now |
| to the extent that | if, when |
| transfer | change, move |
| transmit | send |

## U

| Word/phrase | Alternative |
| --- | --- |
| ultimately | in the end, finally |
| unavailability | lack of |
| undernoted | the following |
| undersigned | I, we |
| undertake | agree, promise, do |
| uniform | same, similar |
| unilateral | one-sided, one-way |
| unoccupied | empty |
| until such time | until |
| utilisation | use |
| utilise | use |

## V

| Word/phrase | Alternative |
| --- | --- |
| variation | change |
| virtually | almost (or edit out) |
| visualise | see, predict |

## W

| Word/phrase | Alternative |
| --- | --- |
| ways and means | ways |
| we have pleasure in | we are glad to |
| whatsoever | whatever, what, any |
| whensoever | when |
| whereas | but |
| whether or not | whether |
| with a view to | to, so that |
| with effect from | from |
| with reference to | about |
| with regard to | about, for |
| with respect to | about, for |
| with the minimum of delay | quickly (or say when) |

## Y

| Word/phrase | Alternative |
| --- | --- |
| you are requested | please |
| your attention is drawn | please see, please note |

## Z

| Word/phrase | Alternative |
| --- | --- |
| zone | area, region |

---

## Words and phrases to avoid

The words and phrases below often crop up in letters and reports. Often you can remove them from a sentence without changing the meaning or the tone. In other words, they add nothing to the message. Try leaving them out of your writing. You'll find your sentences survive and succeed without them.

- a total of
- absolutely
- abundantly
- actually
- all things being equal
- as a matter of fact
- as far as I am concerned
- at the end of the day
- at this moment in time
- basically
- current
- currently
- during the period from
- each and every one
- existing
- extremely
- I am of the opinion that
- I would like to say
- I would like to take this opportunity to
- in due course
- in the end
- in the final analysis
- in this connection
- in total
- in view of the fact that
- it should be understood
- last but not least
- obviously
- of course
- other things being equal
- quite
- really
- really quite
- regarding the (noun), it was
- the fact of the matter is
- the month(s) of
- to all intents and purposes
- to one's own mind
- very

---

## Training from Plain English Campaign

We offer training courses to teach you how to design and write your documents in plain English. We run two types of course:

- **Open courses**, held at various hotels throughout the country, where anyone can attend; and
- **In-house courses**, where we come to an organisation and train your staff. This means we can tailor our training to your organisation's work.

You can also follow our Plain English Diploma Course. This is a 12-month course, leading to a qualification in plain English.

We now offer two courses teaching English grammar. Our Grammarcheck Course is designed to teach delegates the fundamentals of grammar, punctuation, sentence construction and spelling which are so essential for clear communication. We also occasionally hold an Advanced Grammar Course, which goes into more detail on the grammar of standard English.

You may also be interested in 'The Plain English Course' — our pack of materials to help you train your own staff.

For more details on any of the courses, please click on the links throughout this page or use the menu at the top. If you have any specific questions about training courses, please call our training manager Terri Schabel on 01663 744409 or e-mail us at info@plainenglish.co.uk
